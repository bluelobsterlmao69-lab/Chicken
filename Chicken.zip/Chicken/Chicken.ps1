```powershell
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$imagePath = Join-Path $folder "Chicken.jpg"
$audioPath = Join-Path $folder "Chicken.mp3"

if (-not (Test-Path $imagePath)) {
    exit
}

# Play MP3 invisibly and loop it
$player = New-Object -ComObject WMPlayer.OCX
$player.settings.autoStart = $true
$player.settings.setMode("loop", $true)
$player.URL = $audioPath
$player.controls.play()

$image = [System.Drawing.Image]::FromFile($imagePath)
$random = New-Object System.Random
$screens = [System.Windows.Forms.Screen]::AllScreens
$chickens = @()

$end = (Get-Date).AddSeconds(30)

while ((Get-Date) -lt $end) {

    $screen = $screens[$random.Next($screens.Count)]

    $window = New-Object System.Windows.Forms.Form
    $window.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $window.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
    $window.ShowInTaskbar = $false
    $window.TopMost = $true
    $window.Width = 120
    $window.Height = 120

    $picture = New-Object System.Windows.Forms.PictureBox
    $picture.Dock = [System.Windows.Forms.DockStyle]::Fill
    $picture.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $picture.Image = $image

    $x = $screen.WorkingArea.X + $random.Next(
        0,
        [Math]::Max(1, $screen.WorkingArea.Width - 120)
    )

    $y = $screen.WorkingArea.Y + $random.Next(
        0,
        [Math]::Max(1, $screen.WorkingArea.Height - 120)
    )

    $window.Location = New-Object System.Drawing.Point($x, $y)
    $window.Controls.Add($picture)
    $window.Show()

    $chickens += $window

    [System.Windows.Forms.Application]::DoEvents()

    Start-Sleep -Milliseconds 100
}

# Remove all chicken windows
foreach ($window in $chickens) {
    $window.Close()
    $window.Dispose()
}

# Stop the looping music
$player.controls.stop()
$player.close()

$image.Dispose()
```
