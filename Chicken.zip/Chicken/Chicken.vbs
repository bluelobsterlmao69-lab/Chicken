Option Explicit

Dim shell, fso, folder, ps1Path

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
ps1Path = folder & "\Chicken.ps1"

If Not fso.FileExists(ps1Path) Then
    MsgBox "Chicken.ps1 was not found!", 16, "Chicken.vbs"
    WScript.Quit
End If

shell.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & ps1Path & """", 0, False
