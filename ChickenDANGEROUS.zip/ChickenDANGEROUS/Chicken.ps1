```powershell
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$imagePath = Join-Path $folder "Chicken.jpg"
$audioPath = Join-Path $folder "Chicken.mp3"

if (-not (Test-Path $imagePath)) {
    exit
}

if (-not (Test-Path $audioPath)) {
    exit
}

# Hidden looping music
$player = New-Object -ComObject WMPlayer.OCX
$player.settings.autoStart = $true
$player.settings.setMode("loop", $true)
$player.URL = $audioPath
$player.controls.play()

$image = [System.Drawing.Image]::FromFile($imagePath)

$random = New-Object System.Random
$screens = [System.Windows.Forms.Screen]::AllScreens

$chickens = @()

# Number of chickens
$chickenCount = 600000

# Create chickens
for ($i = 0; $i -lt $chickenCount; $i++) {

    $screen = $screens[$random.Next(0, $screens.Count)]

    $window = New-Object System.Windows.Forms.Form

    $window.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $window.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
    $window.ShowInTaskbar = $false
    $window.TopMost = $true

    $window.Width = 120
    $window.Height = 120

    $picture = New-Object System.Windows.Forms.PictureBox
    $picture.Dock = [System.Windows.Forms.DockStyle]::Fill
    $picture.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $picture.Image = $image

    $maxX = [Math]::Max(1, $screen.WorkingArea.Width - $window.Width)
    $maxY = [Math]::Max(1, $screen.WorkingArea.Height - $window.Height)

    $x = $screen.WorkingArea.X + $random.Next(0, $maxX)
    $y = $screen.WorkingArea.Y + $random.Next(0, $maxY)

    $window.Location = New-Object System.Drawing.Point($x, $y)

    $window.Controls.Add($picture)
    $window.Show()

    # Random movement speed
    $speedX = $random.Next(2, 9)

    $speedY = $random.Next(2, 9)

    # Random direction
    if ($random.Next(0, 2) -eq 0) {
        $speedX = -$speedX
    }

    if ($random.Next(0, 2) -eq 0) {
        $speedY = -$speedY
    }

    $chickens += [PSCustomObject]@{
        Window = $window
        SpeedX = $speedX
        SpeedY = $speedY
    }
}

# Run for 10 minutes
$endTime = (Get-Date).AddMinutes(10)

while ((Get-Date) -lt $endTime) {

    foreach ($chicken in $chickens) {

        $window = $chicken.Window

        if ($window.IsDisposed) {
            continue
        }

        $screen = [System.Windows.Forms.Screen]::FromControl($window)
        $bounds = $screen.WorkingArea

        $x = $window.Left + $chicken.SpeedX
        $y = $window.Top + $chicken.SpeedY

        # Bounce off left/right edges
        if ($x -le $bounds.Left) {
            $x = $bounds.Left
            $chicken.SpeedX = [Math]::Abs($chicken.SpeedX)
        }
        elseif ($x + $window.Width -ge $bounds.Right) {
            $x = $bounds.Right - $window.Width
            $chicken.SpeedX = -[Math]::Abs($chicken.SpeedX)
        }

        # Bounce off top/bottom edges
        if ($y -le $bounds.Top) {
            $y = $bounds.Top
            $chicken.SpeedY = [Math]::Abs($chicken.SpeedY)
        }
        elseif ($y + $window.Height -ge $bounds.Bottom) {
            $y = $bounds.Bottom - $window.Height
            $chicken.SpeedY = -[Math]::Abs($chicken.SpeedY)
        }

        $window.Location = New-Object System.Drawing.Point($x, $y)
    }

    [System.Windows.Forms.Application]::DoEvents()

    Start-Sleep -Milliseconds 20
}

# Close all chickens
foreach ($chicken in $chickens) {

    if ($chicken.Window -and -not $chicken.Window.IsDisposed) {
        $chicken.Window.Close()
        $chicken.Window.Dispose()
    }
}

# Stop music
$player.controls.stop()
$player.close()

# Release image
$image.Dispose()
```
